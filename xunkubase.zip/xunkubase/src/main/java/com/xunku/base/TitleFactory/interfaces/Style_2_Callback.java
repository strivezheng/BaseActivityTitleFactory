package com.xunku.base.TitleFactory.interfaces;

/**
 * Created 郑贤鑫 on 2017/2/8.
 */

public interface Style_2_Callback extends StyleCallBack{
    void leftClick();
    void rightClick();
}
