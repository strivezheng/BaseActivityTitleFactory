package com.xunku.base.TitleFactory.interfaces;

/**
 * Created 郑贤鑫 on 2017/2/8.
 */

public interface Style_3_Callback extends StyleCallBack {
    void leftClick();
    void tab1Click();
    void tab2Click();
}
