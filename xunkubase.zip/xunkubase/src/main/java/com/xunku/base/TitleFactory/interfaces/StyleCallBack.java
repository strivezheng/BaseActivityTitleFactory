package com.xunku.base.TitleFactory.interfaces;

/**
 * Created 郑贤鑫 on 2017/1/19.
 */

public interface StyleCallBack {
}
