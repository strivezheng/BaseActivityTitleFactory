package com.xunku.base.dialogFactory;

import android.app.Dialog;

/**
 * Created 郑贤鑫 on 2017/1/23.
 */

public abstract class DialogFactoryable {
    abstract Dialog createDialog();
}
