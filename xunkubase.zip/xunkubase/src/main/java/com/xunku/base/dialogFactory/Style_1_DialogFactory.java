package com.xunku.base.dialogFactory;

import android.app.Dialog;

/**
 * Created 郑贤鑫 on 2017/2/9.
 */

public class Style_1_DialogFactory extends DialogFactoryable {
    @Override
    Dialog createDialog() {
        return null;
    }
}
